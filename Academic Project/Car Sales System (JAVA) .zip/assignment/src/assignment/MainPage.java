package assignment;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class MainPage extends JPanel {
    private JButton AdminButton;
    private JButton SalesmanButton;
    private JButton CustomerButton;
    private JButton exitButton;
    private JButton SuperAdminButton;
    public MainPage (ActionListener onSuperAdmin, ActionListener onAdmin, ActionListener onSalesman, ActionListener onCustomer, ActionListener onExit){
        SuperAdminButton = new JButton("SuperAdmin");
        AdminButton = new JButton("Admin");
        SalesmanButton = new JButton("Salesman");
        CustomerButton = new JButton("Customer");
        exitButton = new JButton("Exit");
        setLayout(new GridLayout(4,1,10,10));
        add(SuperAdminButton);
        add(AdminButton);
        add(SalesmanButton);
        add(CustomerButton);
        add(exitButton);
        SuperAdminButton.addActionListener(onSuperAdmin);
        AdminButton.addActionListener(onAdmin);
        SalesmanButton.addActionListener(onSalesman);
        CustomerButton.addActionListener(onCustomer);
        exitButton.addActionListener(onExit);
    }
}