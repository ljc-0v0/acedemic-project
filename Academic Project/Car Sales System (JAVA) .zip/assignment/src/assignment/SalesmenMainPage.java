package assignment;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class SalesmenMainPage extends JPanel {
    private JButton loginButton;
    private JButton backButton;
    public SalesmenMainPage(ActionListener onLogin, ActionListener onBack) {
        loginButton = new JButton("Login");
        backButton = new JButton("Back");
        setLayout(new GridLayout(3, 1, 10, 10));
        add(loginButton);
        add(backButton);
        loginButton.addActionListener(onLogin);
        backButton.addActionListener(onBack);
    }
 
 
}