package assignment;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
public class CustomerHomePage extends JPanel{
    private JButton ProfileButton;
    private JButton CarButton;
    private JButton HistoryButton;
    private JButton LogOutButton;

    public CustomerHomePage (ActionListener onProfile, ActionListener onCar, ActionListener onHistory, ActionListener onLogOut){
        ProfileButton = new JButton("Profile");
        CarButton = new JButton("View Car");
        HistoryButton = new JButton("Purchased History");
        LogOutButton = new JButton("Log Out");
        setLayout (new GridLayout(4,1));
        add(ProfileButton);
        add(CarButton);
        add(HistoryButton);
        add(LogOutButton);
        ProfileButton.addActionListener(onProfile);
        CarButton.addActionListener(onCar);
        HistoryButton.addActionListener(onHistory);
        LogOutButton.addActionListener(onLogOut);
    }
}