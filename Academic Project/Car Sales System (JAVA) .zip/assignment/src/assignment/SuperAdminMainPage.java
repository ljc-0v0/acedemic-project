package assignment;

import javax.swing.*;

import java.awt.*;

import java.awt.event.*;

public class SuperAdminMainPage extends JPanel {

    private JButton loginButton;

    private JButton registerButton;

    private JButton backButton;
 
    public SuperAdminMainPage(ActionListener onLogin, ActionListener onRegister, ActionListener onBack) {

        loginButton = new JButton("Login");

        registerButton = new JButton("Register");

        backButton = new JButton("Back");
 
        setLayout(new GridLayout(3, 1, 10, 10));

        add(loginButton);

        add(registerButton);

        add(backButton);

        loginButton.addActionListener(onLogin);

        backButton.addActionListener(onBack);

        registerButton.addActionListener(onRegister);


    }
 
 
}
 
 
 