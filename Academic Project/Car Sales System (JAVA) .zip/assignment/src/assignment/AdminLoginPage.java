package assignment;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.function.Consumer;
import javax.swing.*;

public class AdminLoginPage {
    private JFrame frame;
    private JPanel panel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton login,back;
    private JCheckBox showPassword;
    private Consumer<String> onLoginSuccess;
    private ActionListener onBack;
    
    public AdminLoginPage (Consumer<String> onLoginSuccess, ActionListener onBack){
        this.onLoginSuccess = onLoginSuccess;
        this.onBack = onBack;
        
        frame = new JFrame("Admin Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new JPanel(new GridLayout(4,2)); 
        
        panel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        panel.add(usernameField);
        
        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);
        
        panel.add(new JLabel(""));
        showPassword = new JCheckBox("Show Password");
        showPassword.addItemListener( e -> {
            if(e.getStateChange() == ItemEvent.SELECTED){
                passwordField.setEchoChar((char)0);
            }else{
                passwordField.setEchoChar('*');
            }});
        panel.add(showPassword);
        
        login = new JButton("Login");
        panel.add(login);
        login.addActionListener(e ->{
                String adminUsername = usernameField.getText();
                String adminPassword = new String (passwordField.getPassword());
               if(searchAdmin(adminUsername,adminPassword)){
                    JOptionPane.showMessageDialog(frame,"Login Successful");  
                    onLoginSuccess.accept(adminUsername);
                    
                    usernameField.setText("");
                    passwordField.setText("");
               }
               else{
                    JOptionPane.showMessageDialog(frame,"Invalid Username or Password");}});
        
        back = new JButton("Back");
        panel.add(back);
        back.addActionListener(onBack);
        
        frame.add(panel);
        }
    public JPanel getPanel() {
        return panel;
    }

    private boolean searchAdmin(String username, String password){
        try (BufferedReader br = new BufferedReader(new FileReader("Admin.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userPass = line.split("/");
                if (userPass.length >=2 && userPass[0].equals(username) && userPass[1].equals(password)) {
                    return true;
                }
            }
        } catch (Exception e) {
            System.out.println("Error in login...");
        }
        return false;
    }
}