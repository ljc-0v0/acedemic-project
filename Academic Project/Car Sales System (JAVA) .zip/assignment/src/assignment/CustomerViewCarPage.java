package assignment;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class CustomerViewCarPage extends JPanel {
    private JTable carTable;
    private DefaultTableModel tableModel;
    private JButton backButton;
    private JTextField searchField;
    private JTextField minPriceField;
    private JTextField maxPriceField;
    private JButton searchButton;
    private JButton refreshButton;

    public CustomerViewCarPage(ActionListener onBack) {
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchField = new JTextField(15);
        minPriceField = new JTextField(6);
        maxPriceField = new JTextField(6);
        searchButton = new JButton("Search");
        refreshButton = new JButton("Refresh");

        topPanel.add(new JLabel("Keyword:"));
        topPanel.add(searchField);
        topPanel.add(new JLabel("Min Price:"));
        topPanel.add(minPriceField);
        topPanel.add(new JLabel("Max Price:"));
        topPanel.add(maxPriceField);
        topPanel.add(searchButton);
        topPanel.add(refreshButton);

        add(topPanel, BorderLayout.NORTH);

        String[] columnNames = {"ID", "Model", "Price", "Features", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        carTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(carTable);
        add(scrollPane, BorderLayout.CENTER);

        backButton = new JButton("Back");
        backButton.addActionListener(onBack);
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(backButton);
        add(bottomPanel, BorderLayout.SOUTH);

        loadCarData("", null, null);

        refreshButton.addActionListener(e -> {
            searchField.setText("");
            minPriceField.setText("");
            maxPriceField.setText("");
            loadCarData("", null, null);
        });

        searchButton.addActionListener(e -> {
            String keyword = searchField.getText().trim().toLowerCase();
            Double minPrice = parsePrice(minPriceField.getText().trim());
            Double maxPrice = parsePrice(maxPriceField.getText().trim());
            loadCarData(keyword, minPrice, maxPrice);
        });
    }

    private Double parsePrice(String text) {
        if (text.isEmpty()) {
            return null;
        }
        try {
            return Double.parseDouble(text);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void loadCarData(String keyword, Double minPrice, Double maxPrice) {
        tableModel.setRowCount(0);

        File file = new File("store.txt");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Could not create store.txt");
                return;
            }
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length != 8) continue;
                String status = parts[5].toLowerCase();
                if (!status.equals("available")) continue;

                String id = parts[0].toLowerCase();
                String model = parts[1].toLowerCase();
                String priceStr = parts[3];
                String features = parts[4].toLowerCase();

                double price;
                try {
                    price = Double.parseDouble(priceStr);
                } catch (NumberFormatException ex) {
                    continue;
                }

                boolean matchesKeyword = keyword.isEmpty() || id.contains(keyword) || model.contains(keyword) || features.contains(keyword);
                boolean matchesMinPrice = (minPrice == null) || (price >= minPrice);
                boolean matchesMaxPrice = (maxPrice == null) || (price <= maxPrice);

                if (matchesKeyword && matchesMinPrice && matchesMaxPrice) {
                    String[] rowData = {parts[0], parts[1], parts[3], parts[4], parts[5]};
                    tableModel.addRow(rowData);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading from store.txt: " + e.getMessage());
        }
    }
}
