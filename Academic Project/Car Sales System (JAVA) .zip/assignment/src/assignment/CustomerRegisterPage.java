package assignment;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.Date;
        
public class CustomerRegisterPage extends JPanel {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JCheckBox showPasswordCheckBox;
    private JSpinner dateOfBirthSpinner;
    private JTextField addressField;
    private JTextField phoneField;
    private JTextField emailField;
    private JButton submitButton;
    private JButton backButton;

    public CustomerRegisterPage(ActionListener onRegisterSuccess, ActionListener onBack) {
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        submitButton = new JButton("Submit");
        addressField = new JTextField();
        phoneField = new JTextField();
        emailField = new JTextField();
        backButton = new JButton("Back");
        showPasswordCheckBox = new JCheckBox("Show Password");

        SpinnerDateModel dateModel = new SpinnerDateModel();
        dateOfBirthSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateOfBirthSpinner, "yyyy-MM-dd");
        dateOfBirthSpinner.setEditor(dateEditor);

        setLayout(new GridLayout(8, 2));
        add(new JLabel("New Username:"));
        add(usernameField);
        add(new JLabel("New Password:"));
        add(passwordField);
        add(showPasswordCheckBox);
        add(new JLabel());
        add(new JLabel("Date Of Birth"));
        add(dateOfBirthSpinner);
        add(new JLabel("Address"));
        add(addressField);
        add(new JLabel("Phone Number"));
        add(phoneField);
        add(new JLabel("Email"));
        add(emailField);
        add(submitButton);
        add(backButton);

        showPasswordCheckBox.addActionListener(e -> {
            passwordField.setEchoChar(showPasswordCheckBox.isSelected() ? (char) 0 : '*');
        });

        submitButton.addActionListener(e -> {
            String newUsername = usernameField.getText().trim();
            String newPassword = new String(passwordField.getPassword()).trim();
            String address = addressField.getText().trim();
            String phone = phoneField.getText().trim();
            String email = emailField.getText().trim();
            Date dob = (Date) dateOfBirthSpinner.getValue();
            String dobStr = new SimpleDateFormat("yyyy-MM-dd").format(dob);

            if (newUsername.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter username!");
                return;
            }

            if (newPassword.isEmpty() || newPassword.length() < 6) {
                JOptionPane.showMessageDialog(this, "Please enter password at least 6 digit!");
                return;
            }

            if (address.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter address!");
                return;
            }

            if (!email.matches("^[A-Za-z0-9+_.-]+@gmail\\.com$")) {
                JOptionPane.showMessageDialog(this, "Invalid Email Format (Email must end with @gmail.com)");
                return;
            }

            LocalDate dobLocal = dob.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            if (Period.between(dobLocal, LocalDate.now()).getYears() < 18) {
                JOptionPane.showMessageDialog(this, "You must be at least 18 years old to register!");
                return;
            }

            if (!phone.matches("01\\d{8}")) {
                JOptionPane.showMessageDialog(this, "Phone number must start with 01 and have 10 digits!");
                return;
            }

            if (phoneExists(phone)) {
                JOptionPane.showMessageDialog(this, "Phone Number already exists!");
                return;
            }

            if (emailExists(email)) {
                JOptionPane.showMessageDialog(this, "Email already exists!");
                return;
            }

            if (userExists(newUsername)) {
                JOptionPane.showMessageDialog(this, "Username already exists!");
                return;
            }

            registerUser(newUsername, newPassword, dobStr, address, phone, email);
            JOptionPane.showMessageDialog(this, "Register Successful! Your account will accept in 2 days.");
            onRegisterSuccess.actionPerformed(e);
            clearFields();
        });

        backButton.addActionListener(onBack);
    }

    private boolean userExists(String username) {
        return checkFileForValue("users.txt", 0, username) || checkFileForValue("usersApply.txt", 0, username);
    }

    private boolean phoneExists(String phone) {
        return checkFileForValue("users.txt", 4, phone) || checkFileForValue("usersApply.txt", 4, phone);
    }

    private boolean emailExists(String email) {
        return checkFileForValue("users.txt", 5, email) || checkFileForValue("usersApply.txt", 5, email);
    }

    private boolean checkFileForValue(String fileName, int index, String value) {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length > index && parts[index].equals(value)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    private void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
        dateOfBirthSpinner.setValue(new Date());
        addressField.setText("");
        phoneField.setText("");
        emailField.setText("");
    }
    
    private void registerUser(String username, String password, String dob, String address, String phone, String email) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("usersApply.txt", true))) {
            bw.write(username + "/" + password + "/" + dob + "/" + address + "/" + phone + "/" + email + "/Not Accept");
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
