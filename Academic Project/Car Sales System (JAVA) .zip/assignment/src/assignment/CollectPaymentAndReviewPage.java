package assignment;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;
import javax.swing.Timer;

public class CollectPaymentAndReviewPage extends JPanel {
    private String username;
    private JTextField paymentField;
    private JTextArea commentArea;
    private JComboBox<String> paymentMethodBox;
    private JButton saveButton, backButton;
    private JComboBox<String> carSelectionBox;
    private List<String> customerUsernames = new ArrayList<>();
    private Map<String, String> carDataMap = new HashMap<>();
    private long lastUsersFileModified = 0;
    private JButton refreshButton;
    private Sale currentSale;
    private JComboBox<String> CustomerSelection;

    public CollectPaymentAndReviewPage(String username, ActionListener onBack) {
        this.username = username;
        
        setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new GridLayout(8, 2, 5, 5));
        CustomerSelection = new JComboBox<>();
        carSelectionBox = new JComboBox<>();
        paymentField = new JTextField();
        commentArea = new JTextArea(3, 20);
        paymentMethodBox = new JComboBox<>(new String[]{"Cash", "Credit Card", "Online Banking"});
        saveButton = new JButton("Save Sale");
        backButton = new JButton("Back");
        refreshButton = new JButton("Refresh");
        
        refreshButton.addActionListener(e ->{
            loadCarOptions();
            loadCustomerUsernames();
        });

        inputPanel.add(new JLabel("Customer:"));
        inputPanel.add(CustomerSelection);

        inputPanel.add(new JLabel("Select Car:"));
        inputPanel.add(carSelectionBox);

        inputPanel.add(new JLabel("Payment Amount:"));
        inputPanel.add(paymentField);

        inputPanel.add(new JLabel("Payment Method:"));
        inputPanel.add(paymentMethodBox);

        inputPanel.add(new JLabel("Comment:"));
        inputPanel.add(new JScrollPane(commentArea));

        inputPanel.add(saveButton);
        inputPanel.add(backButton);
        inputPanel.add(refreshButton);

        add(inputPanel, BorderLayout.CENTER);

        loadCarOptions();
        loadCustomerUsernames();

        carSelectionBox.addActionListener(e -> {
            String selectedID = (String) carSelectionBox.getSelectedItem();
            if (selectedID == null || !carDataMap.containsKey(selectedID)) {
                currentSale = null;
                return;
            }

            String[] parts = carDataMap.get(selectedID).split("/");
            try {
                double minPrice = Double.parseDouble(parts[2]);
                double maxPrice = Double.parseDouble(parts[3]);
                String carID = parts[0];
                String carModel = parts[1];

                String customerUsername = (String) CustomerSelection.getSelectedItem();
                if (customerUsername == null || customerUsername.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please select a customer.");
                    currentSale = null;
                    return;
                }

                paymentField.setText(String.valueOf(minPrice));

                currentSale = new Sale(customerUsername, carID, carModel, minPrice);
                currentSale.setPriceRange(minPrice, maxPrice);

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error parsing car price data.");
                currentSale = null;
            }
        });


        saveButton.addActionListener(e -> {
            if (currentSale == null) {
                JOptionPane.showMessageDialog(this, "Please select a car first.");
                return;
            }

            try {
                double paymentAmount = Double.parseDouble(paymentField.getText().trim());

                if (paymentAmount <= 0) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid payment amount greater than 0.");
                    return;
                }

                if (paymentAmount < currentSale.getMinPrice()) {
                    JOptionPane.showMessageDialog(this, "Payment amount cannot be less than minimum price: " + currentSale.getMinPrice());
                    return;
                }

                if (paymentAmount > currentSale.getMaxPrice()) {
                    JOptionPane.showMessageDialog(this, "Payment amount cannot exceed maximum price: " + currentSale.getMaxPrice());
                    return;
                }

                currentSale.amountDue = paymentAmount;

                String method = (String) paymentMethodBox.getSelectedItem();
                String comment = commentArea.getText().trim();

                if (comment.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please enter a comment.");
                    return;
                }

                currentSale.collectPayment(method);
                currentSale.addComment(comment);

                try (BufferedWriter writer = new BufferedWriter(new FileWriter("sale.txt", true))) {
                    writer.write(currentSale.toFileString());
                    writer.newLine();
                }

                updateCarStatusToPaid(currentSale.carID);

                paymentField.setText("");
                commentArea.setText("");
                carSelectionBox.setSelectedIndex(-1);
                currentSale = null;

                loadCarOptions();

                JOptionPane.showMessageDialog(this, "Sale saved successfully.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid payment amount.");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error saving sale: " + ex.getMessage());
            }
        });


        backButton.addActionListener(onBack);
    }

    private void loadCarOptions() {
        File storeFile = new File("store.txt");
        File saleFile = new File("sale.txt");

        Set<String> soldCarIDs = new HashSet<>();

        if (saleFile.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(saleFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\\|"); 
                    if (parts.length >= 2) {
                        String soldCarID = parts[1];
                        soldCarIDs.add(soldCarID);
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error reading sale records: " + e.getMessage());
            }
        }

        if (!storeFile.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(storeFile))) {
            String line;
            carSelectionBox.removeAllItems();
            carDataMap.clear();

            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    String[] parts = line.split("/");
                    if (parts.length >= 3) {
                        String id = parts[0];     
                        if (!soldCarIDs.contains(id)) {
                            carSelectionBox.addItem(id);
                            carDataMap.put(id, line);
                        }
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading car list: " + e.getMessage());
        }
    }

    
    private void loadCustomerUsernames() {
        File file = new File("users.txt");
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            CustomerSelection.removeAllItems();
            customerUsernames.clear();

            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    String[] parts = line.split("/");
                    if (parts.length >= 3) {
                        String username = parts[0];
                        customerUsernames.add(username);
                        CustomerSelection.addItem(username);
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading customer list: " + e.getMessage());
        }
    }

    private void updateCarStatusToPaid(String carID) throws IOException {
        File storeFile = new File("store.txt");
        if (!storeFile.exists()) {
            JOptionPane.showMessageDialog(this, "Car store file not found.");
            return;
        }

        List<String> updatedLines = new ArrayList<>();
        boolean carFound = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(storeFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] parts = line.split("/");

                if (parts.length < 7) {
                    JOptionPane.showMessageDialog(this, "Skipping invalid line (insufficient columns): " + line);
                    updatedLines.add(line);  
                    continue;
                }

                if (parts[0].equals(carID)) {
                    parts[5] = "paid";  
                    parts[6] = username; 
                    carFound = true;
                }

                updatedLines.add(String.join("/", parts));
            }
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(storeFile))) {
            for (String updatedLine : updatedLines) {
                writer.write(updatedLine);
                writer.newLine();
            }
        }

        if (!carFound) {
            JOptionPane.showMessageDialog(this, "Car ID not found in store.txt");
        }

        loadCarOptions();
    }

    public static class Sale {
    private String customerUsername;
    private String carID;
    private String carModel;
    private double amountDue;
    private String comment = "";
    private String paymentMethod = "Not paid";

    private double minPrice = 0;
    private double maxPrice = Double.MAX_VALUE;

    public Sale(String customerUsername, String carID, String carModel, double amountDue) {
        this.customerUsername = customerUsername;
        this.carID = carID;
        this.carModel = carModel;
        this.amountDue = amountDue;
    }

    public void setPriceRange(double minPrice, double maxPrice) {
        this.minPrice = minPrice;
        this.maxPrice = maxPrice;
    }

    public double getMinPrice() {
        return minPrice;
    }

    public double getMaxPrice() {
        return maxPrice;
    }

    public void collectPayment(String method) {
        this.paymentMethod = method;
    }

    public void addComment(String comment) {
        this.comment = comment;
    }

    public String toFileString() {
        return customerUsername + "|" + carID + "|" + carModel + "|" + amountDue + "|" + comment + "|" + paymentMethod;
    }
}
    
    public void setUsername(String username) {
        this.username = username;
    }
}










