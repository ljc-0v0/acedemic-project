package assignment;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;
import java.util.regex.Pattern;
import javax.swing.*;
import javax.swing.table.*;

public class AdminApproveCustomer {
    
    private JTable customerTable;
    private DefaultTableModel tableModel;
    private JPanel panel,topPanel,bottomPanel,formPanel,fromBottomPanel;
    private JFrame mainFrame,approveFrame;
    private JComboBox<String> searchOption;
    private JButton searchButton,backButton, editButton,refreshButton, 
            saveButton, cancelButton, deleteButton;
    private JTextField searchField,usernameField,emailField,addressField,
            phoneField,dateOfBirthField;
    private int selectedRow = -1;
    private String currentUsername;

    
    public AdminApproveCustomer(ActionListener onBack){
        mainFrame = new JFrame("Search Customer");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new JPanel(new BorderLayout());
        
        String[] columnNames = {"Name","Date of Birth", "Phone.no",
            "Address", "Email"};
        tableModel = new DefaultTableModel(columnNames, 0) {
        @Override
            public boolean isCellEditable(int row, int column) {
            return false;
    }
};
        
        customerTable = new JTable(tableModel);
        panel.add(customerTable);
        JScrollPane scrollPane = new JScrollPane(customerTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        String[] searchOptions = {"-","Name", "Date of Birth","Phone.no",
            "Address","Email"};
        searchOption = new JComboBox<>(searchOptions);
        
        topPanel = new JPanel();
        searchField = new JTextField(15);
        searchButton = new JButton("Search");
        refreshButton = new JButton("Refresh");
        topPanel.add(searchOption);
        topPanel.add(new JLabel("Search:"));
        topPanel.add(searchField);
        topPanel.add(searchButton);
        topPanel.add(refreshButton);
        panel.add(topPanel, BorderLayout.NORTH);
        
        searchButton.addActionListener(e -> filterCustomer(tableModel));
        searchField.addActionListener(e -> filterCustomer(tableModel));
        refreshButton.addActionListener(e -> loadCustomerData(tableModel));

        editButton = new JButton("Make Changes");
        backButton = new JButton("Back");
        editButton.addActionListener(e -> editPage());
        backButton.addActionListener(onBack);
        bottomPanel = new JPanel();
        bottomPanel.add(editButton);
        bottomPanel.add(backButton);
        panel.add(bottomPanel, BorderLayout.SOUTH);
       
        mainFrame.add(panel);
        mainFrame.pack();
        
        
        loadCustomerData(tableModel);
        
        customerTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                selectedRow = customerTable.getSelectedRow();
            }
        });
    }
    
    public void loadCustomerData(DefaultTableModel tableModel) {
        File file = new File("usersApply.txt");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(mainFrame, 
                        "Could not create usersApply.txt");
                return;
            }
        }
        
        tableModel.setRowCount(0);
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length >= 6) {
                    Object[] rowData = {parts[0], parts[2], parts[4], parts[3],
                        parts[5]};
                    tableModel.addRow(rowData);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(mainFrame,
                    "Error reading from usersApply.txt: " + e.getMessage());
        }
    }
    
    private void filterCustomer(DefaultTableModel tableModel){
    TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
    customerTable.setRowSorter(sorter);
    
    List<RowFilter<DefaultTableModel, Integer>> filters = new ArrayList<>();
    String searchText = searchField.getText().trim();
    sorter.setRowFilter(RowFilter.andFilter(filters));
    
    if (!searchText.isEmpty()) {
        String selectedOption = (String) searchOption.getSelectedItem();
        String safeSearchText = Pattern.quote(searchText);

       
        switch (selectedOption) {
            case "Name":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 0));
                break;
            case "Date of Birth":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 1));
                break;
            case "Address":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 3));
                break;
            case "Phone.no":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 2));
                break;
            case "Email":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 4));
                break;
            case "-":
            default:
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText));
                break;
        }
    }
    if (!filters.isEmpty()) {
            sorter.setRowFilter(RowFilter.andFilter(filters));
       }else {
            sorter.setRowFilter(null); 
        }
    }
    
    private void editPage(){
        selectedRow = customerTable.getSelectedRow();
        
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(approveFrame,
                    "Please select a customer account to approve");
            return;
        }
        
        int modelRow = customerTable.convertRowIndexToModel(selectedRow);
        currentUsername = (String) tableModel.getValueAt(modelRow, 0);
                
        approveFrame = new JFrame("Approve Customer Account");
        approveFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        panel = new JPanel(new BorderLayout());
        approveFrame.setSize(800, 600);
        approveFrame.setLocationRelativeTo(null);
        
        usernameField = new JTextField(); 
        addressField = new JTextField();
        phoneField = new JTextField();
        emailField = new JTextField();
        dateOfBirthField = new JTextField();
        
        usernameField.setEditable(false);
        addressField.setEditable(false);
        phoneField.setEditable(false);
        emailField.setEditable(false);
        dateOfBirthField.setEditable(false);
        
        formPanel = new JPanel(new GridLayout(5, 2));
        formPanel.add(new JLabel("Username:"));
        formPanel.add(usernameField);
        formPanel.add(new JLabel("Date of Birth:"));
        formPanel.add(dateOfBirthField);
        formPanel.add(new JLabel("Address:"));
        formPanel.add(addressField);
        formPanel.add(new JLabel("Phone.no:"));
        formPanel.add(phoneField);
        formPanel.add(new JLabel("Email:"));
        formPanel.add(emailField);
        
        fromBottomPanel = new JPanel(new GridLayout(1,3));
        saveButton =new JButton("Approve");
        saveButton.addActionListener(e-> saveChange());
        fromBottomPanel.add(saveButton);
        deleteButton = new JButton("Reject");
        deleteButton.addActionListener(e-> rejectApprovement());
        fromBottomPanel.add(deleteButton);
        cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e-> approveFrame.dispose());
        fromBottomPanel.add(cancelButton);

        approveFrame.add(formPanel,BorderLayout.CENTER);
        approveFrame.add(fromBottomPanel,BorderLayout.SOUTH);
        approveFrame.setVisible(true);
        
        loadProfile();
        
    }
    
    private void loadProfile(){
        try (BufferedReader br = new BufferedReader(new FileReader("usersApply.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length >= 6 && parts[0].equals(currentUsername)) {
                    usernameField.setText(parts[0]);
                    dateOfBirthField.setText(parts[2]);
                    phoneField.setText(parts[4]);
                    addressField.setText(parts[3]);
                    emailField.setText(parts[5]);
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void saveChange() {
    int confirm = JOptionPane.showConfirmDialog(mainFrame, 
        "Are you sure u want to approve " + currentUsername + "?", "Confirm Approve", 
        JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) {
        return; 
    }
    String password = null;
    String dob = dateOfBirthField.getText();        
    String phone = phoneField.getText();
    String address = addressField.getText();
    String email = emailField.getText();
    
    try(BufferedReader reader = new BufferedReader(new FileReader("usersApply.txt"))) {
        String line;
        
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split("/");
            
            if (parts.length >= 6 && parts[0].equals(currentUsername)) {
                
                password = parts[1];
                dob = parts[2];
                address = parts[3];
                phone = parts[4];
                email = parts[5];
            }
        }
        reader.close();
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("users.txt", true))) {
            bw.write(currentUsername + "/" + password + "/" + dob + "/" + address + "/" 
                    + phone + "/" + email );
            bw.newLine();
        }

        deleteRecord();
        approveFrame.dispose();
        loadCustomerData(tableModel);
            
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(approveFrame, "Failed to update: " + e.getMessage());
    }
    
}   
    private void deleteRecord(){
        if (currentUsername == null || currentUsername.isEmpty()) {
        JOptionPane.showMessageDialog(mainFrame, "Please select "
                + "a customer account to delete");
        return;
    }
        
        List<String> lines = new ArrayList<>();
        try(BufferedReader reader = new BufferedReader(new FileReader("usersApply.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
            String[] parts = line.split("/");
                 if (parts.length >= 6 && !parts[0].equals(currentUsername)) {
                    lines.add(line); 
                 }
            }
        }catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(approveFrame, 
                "Failed to update: " + e.getMessage());
    }
        try (PrintWriter writer = new PrintWriter(new FileWriter("usersApply.txt"))) {
        for (String line : lines) {
            writer.println(line);
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(mainFrame, 
                "Error writing file: " + e.getMessage());
    }
    
    JOptionPane.showMessageDialog(approveFrame, 
            "Changes saved successfully!");
    approveFrame.dispose();
    currentUsername = null;
    loadCustomerData(tableModel); 
}
    
    private void rejectApprovement(){
    int confirm = JOptionPane.showConfirmDialog(mainFrame, 
        "Are you sure u want to reject " + currentUsername + "?", 
        "Confirm Reject", JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) {
        return; 
    }
    deleteRecord();
    }
    
    public JPanel getPanel(){
         return panel;
     }
}
