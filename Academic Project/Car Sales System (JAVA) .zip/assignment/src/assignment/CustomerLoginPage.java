package assignment;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.function.Consumer;
public class CustomerLoginPage extends JPanel {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JCheckBox showPasswordCheckBox;
    private JButton submitButton;
    private JButton backButton;
 
    public CustomerLoginPage(Consumer<String> onLoginSuccess, ActionListener onBack)  {
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        submitButton = new JButton("Login");
        backButton = new JButton("Back");
        showPasswordCheckBox = new JCheckBox("Show Password");
        setLayout(new GridLayout(4, 2));
        add(new JLabel("Username:"));
        add(usernameField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(showPasswordCheckBox);
        add(new JLabel());
        add(submitButton);
        add(backButton);
        showPasswordCheckBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (showPasswordCheckBox.isSelected()) {
                    passwordField.setEchoChar((char) 0); 
                } else {
                    passwordField.setEchoChar('*');
                }
            }
        });
 
        submitButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
           
            
            if (checkLogin(username,password)) {
                JOptionPane.showMessageDialog(this, "Login Successful");
                onLoginSuccess.accept(username);
                
                usernameField.setText("");
                passwordField.setText("");
            } else if(checkAccept(username)){
                JOptionPane.showMessageDialog(this,"Please wait for admin to accept.");
                
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Username or Password");
            }
        });
 
        backButton.addActionListener(onBack); 
    }
    
    private boolean checkAccept(String username) {
        try (BufferedReader br = new BufferedReader(new FileReader("usersApply.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userPass = line.split("/");
                if (userPass.length >=1 && userPass[0].equals(username) && userPass[6].equals("Not Accept")) {
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
        
    private boolean checkLogin(String username, String password) {
        try (BufferedReader br = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userPass = line.split("/");
                if (userPass.length >=2 && userPass[0].equals(username) && userPass[1].equals(password)) {
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
 