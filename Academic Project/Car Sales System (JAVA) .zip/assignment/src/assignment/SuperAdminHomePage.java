package assignment;

import javax.swing.*;

import java.awt.*;

import java.awt.event.*;

public class SuperAdminHomePage extends JPanel{

    private JButton ProfileButton;

    private JButton AdminButton;
    
    private JButton SearchButton;

    private JButton SalesmanButton;

    private JButton LogOutButton;


    public SuperAdminHomePage (ActionListener onProfile,ActionListener onSearch, ActionListener onAdmin, ActionListener onSalesman, ActionListener onLogOut){

        ProfileButton = new JButton("Profile");

        AdminButton = new JButton("Admin");
        
        SearchButton = new JButton("Search Admin");

        SalesmanButton = new JButton("Salesman");

        LogOutButton = new JButton("Log Out");

        setLayout (new GridLayout(4,1));

        add(ProfileButton);

        add(AdminButton);
        add(SearchButton);
        add(SalesmanButton);

        add(LogOutButton);

        ProfileButton.addActionListener(onProfile);

        AdminButton.addActionListener(onAdmin);
        
        SearchButton.addActionListener(onSearch);

        SalesmanButton.addActionListener(onSalesman);

        LogOutButton.addActionListener(onLogOut);

    }

}

 