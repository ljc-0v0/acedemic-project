package assignment;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.Timer;

public class UpdateCarStatus extends JPanel {
    private String username;
    private JTable carTable;
    private DefaultTableModel tableModel;
    private JButton updateButton;
    private JButton refreshButton;
    private long lastFileModified;

    public UpdateCarStatus(String username, ActionListener onBack) {
        this.username = username;
        setLayout(new BorderLayout());
        
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField searchField = new JTextField(20);
        topPanel.add(new JLabel("Search by Car ID:"));
        topPanel.add(searchField);
        add(topPanel, BorderLayout.NORTH);
        searchField.addActionListener(e -> {
        String carId = searchField.getText().trim();
        if (carId.isEmpty()) {
            loadCarData(); 
        } else {
            searchCarById(carId);
        }
    });

        String[] columns = {"ID", "Model", "Min Price", "Max Price", "Features", "Status", "Salesman", "Admin"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        carTable = new JTable(tableModel);
        carTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(carTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout());
        updateButton = new JButton("Confirm");
        JButton backButton = new JButton("Back");
        refreshButton = new JButton("Refresh");
        
        refreshButton.addActionListener(e ->{
            loadCarData();
        });

        bottomPanel.add(updateButton);
        bottomPanel.add(backButton);
        bottomPanel.add(refreshButton);
        add(bottomPanel, BorderLayout.SOUTH);

        loadCarData();

        updateButton.addActionListener(e -> {
            int selectedRow = carTable.getSelectedRow();
            if (selectedRow != -1) {
                String currentStatus = (String) tableModel.getValueAt(selectedRow, 5);
                StatusEditDialog dialog = new StatusEditDialog((Frame) SwingUtilities.getWindowAncestor(this), currentStatus);
                dialog.setVisible(true);
                String newStatus = dialog.getSelectedStatus();
                if (newStatus != null && !newStatus.equals(currentStatus)) {
                    tableModel.setValueAt(newStatus, selectedRow, 5);
                    if ("available".equalsIgnoreCase(newStatus)) {
                        tableModel.setValueAt("-", selectedRow, 6);
                    }
                    updateCarStatusInFile();
                    loadCarData();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a row first!");
            }
        });

        backButton.addActionListener(onBack);
    
        carTable.getSelectionModel().addListSelectionListener(e -> {
            int selectedRow = carTable.getSelectedRow();
            if (selectedRow != -1) {
                String salesman = (String) tableModel.getValueAt(selectedRow, 6);
                String status = (String) tableModel.getValueAt(selectedRow, 5);
                boolean isEnabled = (salesman.equals(this.username) || salesman.equals("-"))
                                    && !"paid".equalsIgnoreCase(status);
                updateButton.setEnabled(isEnabled);
            } else {
                updateButton.setEnabled(false);
            }
        });
    }

    private void loadCarData() {
        tableModel.setRowCount(0);
        try (BufferedReader reader = new BufferedReader(new FileReader("store.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] row = line.split("/");
                if (row.length == 8) {
                    tableModel.addRow(row);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading car data: " + e.getMessage());
        }
    }
    
    private void searchCarById(String carId) {
    tableModel.setRowCount(0); 
    try (BufferedReader br = new BufferedReader(new FileReader("store.txt"))) {
        String line;
        boolean found = false;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split("/");
            if (parts.length == 8 && parts[0].equalsIgnoreCase(carId)) {
                tableModel.addRow(parts);
                found = true;
                break;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(this, "No car found with ID: " + carId);
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Failed to search car: " + e.getMessage());
    }
}

    private void updateCarStatusInFile() {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter("store.txt"))) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String[] parts = new String[8];
            for (int j = 0; j < 8; j++) {
                parts[j] = String.valueOf(tableModel.getValueAt(i, j));
            }

            String status = parts[5];

            int selectedRow = carTable.getSelectedRow(); 
            if (i == selectedRow && ("booked".equalsIgnoreCase(status) || "paid".equalsIgnoreCase(status))) {
                parts[6] = username;
            }

            writer.write(String.join("/", parts));
            writer.newLine();
        }
        JOptionPane.showMessageDialog(this, "Car status updated successfully.");
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error writing to store.txt: " + e.getMessage());
    }
}


    public void setUsername(String username) {
        this.username = username;
    }

    private class StatusEditDialog extends JDialog {
        private String selectedStatus;
        private JComboBox<String> statusComboBox;

        public StatusEditDialog(Frame owner, String currentStatus) {
            super(owner, "Edit Car Status", true);
            setLayout(new BorderLayout());

            statusComboBox = new JComboBox<>(new String[]{"available", "booked"});
            statusComboBox.setSelectedItem(currentStatus);

            if ("paid".equalsIgnoreCase(currentStatus)) {
                statusComboBox.setEnabled(false);
            }

            add(statusComboBox, BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel();
            JButton confirmButton = new JButton("Confirm");
            JButton cancelButton = new JButton("Cancel");

            confirmButton.addActionListener(e -> {
                selectedStatus = (String) statusComboBox.getSelectedItem();
                dispose();
            });

            cancelButton.addActionListener(e -> dispose());

            buttonPanel.add(confirmButton);
            buttonPanel.add(cancelButton);
            add(buttonPanel, BorderLayout.SOUTH);

            pack();
            setLocationRelativeTo(owner);
        }

        public String getSelectedStatus() {
            return selectedStatus;
        }
    }
}









