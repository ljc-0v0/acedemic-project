<?php
session_start();
include('tng_conn.php');
include('conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['userid'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit();
}

$user_id = $_SESSION['userid'];

if (!$dbConn) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit();
}

$period = isset($_GET['period']) ? $_GET['period'] : 'week';

switch ($period) {
    case 'week':
        $date_format = "%x-W%v";
        break;
    case 'year':
        $date_format = "%Y";
        break;
    case 'month':
    default:
        $date_format = "%Y-%m";
        break;
}

$query = "
    SELECT DATE_FORMAT(DueDate, '$date_format') AS period, status, COUNT(*) AS count
    FROM user_task
    WHERE userid = ?
    GROUP BY period, status
    ORDER BY MIN(DueDate) ASC
";

$stmt = $dbConn->prepare($query);
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Query prepare failed']);
    exit();
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$data = [];

while ($row = $result->fetch_assoc()) {
    $p = $row['period'];
    $status = strtolower(trim($row['status']));
    if (!isset($data[$p])) {
        $data[$p] = ['completed' => 0, 'incomplete' => 0];
    }
    if ($status === 'completed') {
        $data[$p]['completed'] = (int)$row['count'];
    } else {
        $data[$p]['incomplete'] = (int)$row['count'];
    }
}

$stmt->close();
$dbConn->close();

echo json_encode([
    'success' => true,
    'data' => $data
]);
