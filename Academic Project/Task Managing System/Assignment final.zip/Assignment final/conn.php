<?php

$localhost = 'localhost';
$user = 'root';
$pass = '';
$dbName = 'tng_assignment';

$dbConn = mysqli_connect($localhost, $user, $pass, $dbName);
