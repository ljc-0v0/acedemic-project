<?php
session_start();
$userID = $_SESSION['userid'];



header('Content-Type: application/json');

if (isset($_POST["submitForm"])) {
    $activity = $_POST["activity"];
    $friendInput = $_POST["friend"];
    $dueDate = $_POST["dueDate"];

    include "conn.php";

    $friendID = null;
    $friend = null;


    if (!empty(trim($friendInput))) {
        $findFriend = $dbConn->prepare("SELECT UserID FROM user_info WHERE Username = ?");
        $findFriend->bind_param("s", $friendInput);
        $findFriend->execute();
        $findResult = $findFriend->get_result();

        if ($row = $findResult->fetch_assoc()) {
            $friendID = $row['UserID'];
            $friend = $friendInput;
        }
        $findFriend->close();
    }

    $sql = $dbConn->prepare("INSERT INTO user_task (TaskActivity, UserID, FriendUserID, FriendUser, DueDate) VALUES (?, ?, ?, ?, ?)");
    $sql->bind_param("siiss", $activity, $userID, $friendID, $friend, $dueDate);
    $sql->execute();

    if ($sql->affected_rows <= 0) {
        die('<script>alert("Fail: unable to insert data!");window.history.go(-1);</script>');
    }

    $sql->close();

    echo "<script>alert('Successfully inserted data!');</script>";
    header("Location: index.php");
    exit();
}

if (isset($_POST["selectedDate"])) {
    $selectedDate = $_POST["selectedDate"];

    include "conn.php";

    $userTasksQuery = $dbConn->prepare("SELECT * FROM user_task WHERE UserID = ? AND DueDate = ?");
    $userTasksQuery->bind_param("is", $userID, $selectedDate);
    $userTasksQuery->execute();
    $userResult = $userTasksQuery->get_result();

    $userTasks = [];
    while ($row = $userResult->fetch_assoc()) {
        $userTasks[] = $row;
    }

    $friendTasks = [];

    $friendQuery = $dbConn->prepare("SELECT * FROM user_task WHERE FriendUserID = ? AND DueDate = ?");
    if ($friendQuery) {
        $friendQuery->bind_param("is", $userID, $selectedDate);
        $friendQuery->execute();
        $friendResult = $friendQuery->get_result();

        while ($row = $friendResult->fetch_assoc()) {
            $friendTasks[] = $row;
        }
        $friendQuery->close();
    }

    $allTasks = array_merge($userTasks, $friendTasks);

    echo json_encode([
        'success' => true,
        'user_task' => $allTasks
    ]);

    exit();
}
if ($_POST['action'] === 'update_status') {
    $taskId = $_POST['task_id'] ?? '';
    $status = $_POST['status'] ?? '';

    include "conn.php";

    if (empty($taskId) || empty($status)) {
        echo json_encode(['success' => false, 'error' => 'Missing task ID or status']);
        exit;
    }

    if (!is_numeric($taskId)) {
        echo json_encode(['success' => false, 'error' => 'Invalid task ID']);
        exit;
    }

    $taskId = (int)$taskId;

    try {
        if ($status === "completed") {
            $createdDateStmt = $dbConn->prepare("SELECT createdDate FROM user_task WHERE TaskID = ?");
            $createdDateStmt->bind_param("i", $taskId);
            $createdDateStmt->execute();
            $createdDateStmt->bind_result($createdDate);
            $createdDateStmt->fetch();
            $createdDateStmt->close();

            if ($createdDate) {
                date_default_timezone_set('Asia/Kuala_Lumpur');

                $createdDateTime = new DateTime($createdDate);
                $currentDateTime = new DateTime();

                $interval = $currentDateTime->diff($createdDateTime);

                $timeSpent = formatTimeSpent($interval);
            } else {
                $timeSpent = "0 seconds";
            }

            $stmt = $dbConn->prepare("UPDATE user_task SET Status = ?, timeSpent = ? WHERE TaskID = ?");
            $stmt->bind_param("ssi", $status, $timeSpent, $taskId);
        } else {
            $stmt = $dbConn->prepare("UPDATE user_task SET Status = ?, timeSpent = NULL WHERE TaskID = ?");
            $stmt->bind_param("si", $status, $taskId);
        }

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'timeSpent' => $timeSpent ?? null]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Database update failed: ' . $stmt->error]);
        }

        $stmt->close();
        $dbConn->close();
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

function formatTimeSpent($interval)
{
    $parts = [];

    if ($interval->d > 0) {
        $parts[] = $interval->d . ' day' . ($interval->d > 1 ? 's' : '');
    }
    if ($interval->h > 0) {
        $parts[] = $interval->h . ' hour' . ($interval->h > 1 ? 's' : '');
    }
    if ($interval->i > 0) {
        $parts[] = $interval->i . ' minute' . ($interval->i > 1 ? 's' : '');
    }
    if ($interval->s > 0) {
        $parts[] = $interval->s . ' second' . ($interval->s > 1 ? 's' : '');
    }

    if (empty($parts)) {
        return '0 seconds';
    }

    return implode(' ', $parts);
}

if ($_POST['action'] === 'edit_task') {
    include "conn.php";

    $taskId = $_POST['task_id'] ?? '';
    $taskName = $_POST['editActivityInput'] ?? '';
    $friendInput = $_POST['editFriendInput'] ?? '';
    $dueDate = $_POST['editDueDate'] ?? '';

    $friendID = null;
    $friendName = null;

    if (!empty(trim($friendInput))) {
        $findFriend = $dbConn->prepare("SELECT UserID FROM user_info WHERE Username = ?");
        $findFriend->bind_param("s", $friendInput);
        $findFriend->execute();
        $findResult = $findFriend->get_result();

        if ($row = $findResult->fetch_assoc()) {
            $friendID = $row['UserID'];
            $friendName = $friendInput;
        }
        $findFriend->close();
    }

    $stmt = $dbConn->prepare("UPDATE user_task SET TaskActivity = ?, FriendUserID = ?, FriendUser = ?, DueDate = ? WHERE TaskID = ?");
    $stmt->bind_param("sissi", $taskName, $friendID, $friendName, $dueDate, $taskId);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Task updated successfully']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to update task: ' . $stmt->error]);
    }

    $stmt->close();
    exit;
}

if ($_POST['action'] === 'delete_task') {
    include "conn.php";

    $taskId = $_POST['task_id'] ?? '';

    $stmt = $dbConn->prepare("DELETE from user_task WHERE TaskID = ?");
    $stmt->bind_param("s", $taskId);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Task deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to delete task']);
    }

    $stmt->close();
    exit;
}

if ($_POST['action'] === 'searchFriend') {
    include "conn.php";

    $friendInput = $_POST['searchFriend'];
    $friendID = null;
    $friendName = null;

    if (!empty(trim($friendInput))) {
        $findFriend = $dbConn->prepare("SELECT * FROM user_info WHERE Username = ?");
        $findFriend->bind_param("s", $friendInput);
        $findFriend->execute();
        $findResult = $findFriend->get_result();

        if ($row = $findResult->fetch_assoc()) {
            $friendID = $row['UserID'];
            $friendName = $friendInput;
        }
        $findFriend->close();
        header('Location: searchFriend.php?friendID=' . urlencode($friendID) . '&friendName=' . urlencode($friendName));
        exit;
    }
    header("Location: index.php");
    exit;
}


if ($_POST['action'] === 'backButton') {
    header("Location: index.php");
    exit;
}
