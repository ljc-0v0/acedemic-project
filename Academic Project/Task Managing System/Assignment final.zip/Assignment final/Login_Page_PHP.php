<?php

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

include "tng_conn.php";

// Take Data From Database
$check_sql_email = "SELECT * FROM User_Info WHERE EmailAccount = ?";
$stmt_email = $dbConn->prepare($check_sql_email);
$stmt_email->bind_param("s", $email);
$stmt_email->execute();
$result_email = $stmt_email->get_result();

// Check Login
if ($result_email->num_rows > 0) {
    $row = $result_email->fetch_assoc();


    if ($password === $row["UserPassword"]) {
        $username = $row["Username"];
        $user_id = $row["UserID"];

        session_start();

        $_SESSION['user_email'] = $email;
        $_SESSION['username'] = $username;
        $_SESSION['userid'] = $user_id;
        setcookie('user_email', $email, 0, "/");
        setcookie('username', $username, 0, "/");
        setcookie('userid', $user_id, 0, "/");

        echo "<script>alert('Login successfully!');</script>";
        header('Location: index.php');
        exit();
    } else {
        echo "<script>alert('Email or Password Incorrect!'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Email or Password Incorrect!'); window.history.back();</script>";
}

$stmt->close();
$dbConn->close();


// if ($username === 'admin' && $password === '1234') {
//     echo "Login Success!";
// } else {
//     echo "Invalid username or password";
// }
