<?php
session_start();
include('tng_conn.php');
header('Content-Type: application/json');

if (!isset($_SESSION['userid'])) {
  echo json_encode(["success" => false, "message" => "User not logged in"]);
  exit();
}

$user_id = $_SESSION['userid'];

if (!empty($_FILES)) {
  $field = $_POST['field'];
  $file = $_FILES['file'];

  $field_map = [
    "ProfilePicture" => "ProfilePicture",
    "BackgroundPicture" => "BackgroundPicture"
  ];

  if (!array_key_exists($field, $field_map)) {
    echo json_encode(["success" => false, "message" => "Invalid file field"]);
    exit();
  }

  $target_dir = "uploads/";
  if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);

  $file_ext = pathinfo($file['name'], PATHINFO_EXTENSION);
  $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
  if (!in_array(strtolower($file_ext), $allowed_ext)) {
    echo json_encode(["success" => false, "message" => "Invalid file type"]);
    exit();
  }

  $file_name = $user_id . "_" . $field . "_" . time() . "." . $file_ext;
  $target_file = $target_dir . $file_name;

  if (move_uploaded_file($file["tmp_name"], $target_file)) {
    $db_field = $field_map[$field];
    $stmt = $dbConn->prepare("UPDATE user_info SET $db_field = ? WHERE userid = ?");
    $stmt->bind_param("si", $target_file, $user_id);
    $stmt->execute();
    $stmt->close();

    echo json_encode(["success" => true, "message" => "Image uploaded", "path" => $target_file]);
  } else {
    echo json_encode(["success" => false, "message" => "File upload failed"]);
  }
  $dbConn->close();
  exit();
}

$data = json_decode(file_get_contents("php://input"), true);
$field = $data['field'] ?? '';
$value = $data['value'] ?? '';

$field_map = [
  "DOB:" => "DateofBirth",
  "Phone.no:" => "PhoneNumber",
  "Facebook:" => "FacebookAccount",
  "Instagram:" => "InstagramAccount"
];

if (!array_key_exists($field, $field_map)) {
  echo json_encode(["success" => false, "message" => "Invalid text field"]);
  exit();
}

$db_field = $field_map[$field];
$stmt = $dbConn->prepare("UPDATE user_info SET $db_field = ? WHERE userid = ?");
$stmt->bind_param("si", $value, $user_id);

if ($stmt->execute()) {
  echo json_encode(["success" => true, "message" => "Field updated"]);
} else {
  echo json_encode(["success" => false, "message" => $dbConn->error]);
}

$stmt->close();
$dbConn->close();
