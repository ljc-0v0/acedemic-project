document.addEventListener("DOMContentLoaded", function () {
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const weekdays = [
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday",
    "sunday",
  ];

  const today = new Date();
  let selectedDate = today;
  let month = today.getMonth();
  let year = today.getFullYear();
  const prevMonthButton = document.getElementById("prevMonth");
  const nextMonthButton = document.getElementById("nextMonth");
  const selectedDateHeader = document.getElementById("selectedDate");

  const newFrame = document.getElementById("frame");
  const addTaskButton = document.getElementById("addTaskButton");

  function updateCalendar(month, year) {
    let firstDay = new Date(year, month, 1).getDay();
    firstDay = firstDay === 0 ? 6 : firstDay - 1;

    // Fix: Get last day of previous month correctly
    const prevMonthLastDay = new Date(year, month, 0).getDate();

    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const dayGrid = document.getElementById("dayGrid");
    dayGrid.innerHTML = "";

    // Previous month days
    for (let i = 0; i < firstDay; i++) {
      const dayCell = document.createElement("div");
      dayCell.className = `${weekdays[i]} prevOrNext`;
      dayCell.textContent = prevMonthLastDay - firstDay + i + 1;
      dayGrid.appendChild(dayCell);
    }

    // Current month days
    for (let i = 1; i <= daysInMonth; i++) {
      const currentDate = new Date(year, month, i);
      const currentWeekday = currentDate.getDay();
      const adjustedWeekday = currentWeekday === 0 ? 6 : currentWeekday - 1;

      const dayCell = document.createElement("div");
      dayCell.className = `${weekdays[adjustedWeekday]}`;
      dayCell.textContent = i;

      // Highlight today
      if (
        i === today.getDate() &&
        month === today.getMonth() &&
        year === today.getFullYear()
      ) {
        dayCell.classList.add("currentDay");
        const selectedDateInForm = (selectedDateHeader.textContent =
          today.toLocaleDateString("en-US", {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
          }));
        showTodaySelectedDate(today);
        sendTodayDatetoPHP(today);
      }

      // Highlight selected date
      if (
        selectedDate &&
        i === selectedDate.getDate() &&
        month === selectedDate.getMonth() &&
        year === selectedDate.getFullYear()
      ) {
        dayCell.classList.add("selected");
      }

      dayCell.addEventListener("click", function () {
        showSelectedDate(new Date(year, month, i));
        sendDatetoPHP(new Date(year, month, i + 1));
      });

      dayGrid.appendChild(dayCell);
    }

    // Next month days
    const totalCells = 42; // 6 weeks × 7 days
    const remainingCells = totalCells - (firstDay + daysInMonth);

    for (let i = 1; i <= remainingCells; i++) {
      const dayCell = document.createElement("div");
      dayCell.className = `prevOrNext ${
        weekdays[(firstDay + daysInMonth + i - 1) % 7]
      }`;
      dayCell.textContent = i;
      dayGrid.appendChild(dayCell);
    }

    // Update header
    document.getElementById(
      "monthYear"
    ).textContent = `${monthNames[month]} ${year}`;
  }

  prevMonthButton.addEventListener("click", function () {
    month--;
    if (month < 0) {
      month = 11;
      year--;
    }

    updateCalendar(month, year);
  });

  nextMonthButton.addEventListener("click", function () {
    month++;
    if (month > 11) {
      month = 0;
      year++;
    }

    updateCalendar(month, year);
  });

  function showSelectedDate(date) {
    selectedDate = date;

    selectedDateHeader.textContent = date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });

    const dayInForm = String(date.getDate()).padStart(2, "0");
    const monthInForm = String(date.getMonth() + 1).padStart(2, "0");
    const yearInForm = String(date.getFullYear());

    const formattedDate = `${dayInForm}/${monthInForm}/${yearInForm}`;
    const nextDay = new Date(date);
    nextDay.setDate(date.getDate() + 1);
    const inputDate = nextDay.toISOString().split("T")[0];

    document.getElementById("selectedDateInForm").textContent = formattedDate;
    document.getElementById("dueDateInput").value = inputDate;
  }

  function showTodaySelectedDate(date) {
    selectedDate = date;

    selectedDateHeader.textContent = date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });

    const dayInForm = String(date.getDate()).padStart(2, "0");
    const monthInForm = String(date.getMonth() + 1).padStart(2, "0");
    const yearInForm = String(date.getFullYear());

    const formattedDate = `${dayInForm}/${monthInForm}/${yearInForm}`;
    const inputDate = date.toISOString().split("T")[0];

    document.getElementById("selectedDateInForm").textContent = formattedDate;
    document.getElementById("dueDateInput").value = inputDate;
  }

  function sendDatetoPHP(date) {
    const selectedDatetoPHP = date.toISOString().split("T")[0];

    fetch("dashboard.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: "selectedDate=" + encodeURIComponent(selectedDatetoPHP),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Full response:", data);

        let tasks = [];
        if (data.success && data.user_task) {
          tasks = data.user_task;
        } else if (Array.isArray(data)) {
          tasks = data;
        }

        console.log("Tasks to display:", tasks);

        const taskContainer = document.getElementById("taskProgress");

        // Store references BEFORE clearing innerHTML
        const header = document.getElementById("selectedDate");
        const addButton = document.getElementById("addTaskButton");

        // Clear container
        taskContainer.innerHTML = "";

        if (header) {
          taskContainer.appendChild(header);
        }
        if (addButton) {
          taskContainer.appendChild(addButton);
        }

        if (tasks && tasks.length > 0) {
          tasks.forEach((task) => {
            showTaskFromDB(task);
          });
        } else {
          console.log("No tasks to display");
          const noTasksMsg = document.createElement("p");
          noTasksMsg.textContent = "No tasks for this date";
          noTasksMsg.style.color = "#666";
          noTasksMsg.style.textAlign = "center";
          taskContainer.appendChild(noTasksMsg);
        }
      })
      .catch((error) => console.error("Error:", error));
  }

  function sendTodayDatetoPHP(date) {
    const selectedDatetoPHP = date.toISOString().split("T")[0];

    fetch("dashboard.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: "selectedDate=" + encodeURIComponent(selectedDatetoPHP),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Full response:", data);

        let tasks = [];
        if (data.success && data.user_task) {
          tasks = data.user_task;
        } else if (Array.isArray(data)) {
          tasks = data;
        }

        console.log("Tasks to display:", tasks);

        const taskContainer = document.getElementById("taskProgress");

        // Store references BEFORE clearing innerHTML
        const header = document.getElementById("selectedDate");
        const addButton = document.getElementById("addTaskButton");

        // Clear container
        taskContainer.innerHTML = "";

        if (header) {
          taskContainer.appendChild(header);
        }
        if (addButton) {
          taskContainer.appendChild(addButton);
        }

        if (tasks && tasks.length > 0) {
          tasks.forEach((task) => {
            showTaskFromDB(task);
          });
        } else {
          console.log("No tasks to display");
          const noTasksMsg = document.createElement("p");
          noTasksMsg.textContent = "No tasks for this date";
          noTasksMsg.style.color = "#666";
          noTasksMsg.style.textAlign = "center";
          taskContainer.appendChild(noTasksMsg);
        }
      })
      .catch((error) => console.error("Error:", error));
  }

  function addTaskFrame() {
    newFrame.classList.add("active");

    const closeButton = document.getElementById("closeButton");
    const taskForm = document.getElementById("taskForm");

    closeButton.addEventListener("click", closeForm);
    taskForm.addEventListener("submit", submitForm);

    function closeForm() {
      newFrame.classList.remove("active");
    }

    function submitForm() {
      alert("Task Added");
      closeForm();
    }
  }

  addTaskButton.addEventListener("click", addTaskFrame);

  document.addEventListener("click", function (e) {
    if (e.target.classList.contains("taskButton")) {
      const container = e.target.closest(".taskNButton");
      const task = container.querySelector(".task");
      const taskButton = container.querySelector(".taskButton");
      const taskId = container.dataset.taskId;

      if (taskButton.classList.contains("incompleteTask")) {
        taskButton.classList.replace("incompleteTask", "completedTask");
        task.classList.replace("incompleteTask", "completedTask");
        changeTaskStatus(taskId, "completed");
        location.reload();
      } else if (taskButton.classList.contains("completedTask")) {
        taskButton.classList.replace("completedTask", "incompleteTask");
        task.classList.replace("completedTask", "incompleteTask");
        changeTaskStatus(taskId, "incomplete");
        location.reload();
      }
    }
  });

  function showTaskFromDB(taskData) {
    const taskNButtonContainer = document.createElement("div");
    taskNButtonContainer.classList.add("taskNButton");

    taskNButtonContainer.dataset.taskId = taskData.TaskID;
    taskNButtonContainer.dataset.taskName = taskData.TaskActivity;
    taskNButtonContainer.dataset.friendName = taskData.FriendUser;
    taskNButtonContainer.dataset.dueDate = taskData.DueDate;
    taskNButtonContainer.dataset.timeSpent = taskData.timeSpent;

    const taskTitle = document.createElement("h1");
    taskTitle.textContent = taskData.TaskActivity || "Unnamed Task";

    const taskButton = document.createElement("button");
    taskButton.textContent = "✔";

    const taskStatus = taskData.Status || "incomplete";
    if (taskStatus === "completed") {
      taskTitle.classList.add("task", "completedTask");
      taskButton.classList.add("taskButton", "completedTask");
    } else {
      taskTitle.classList.add("task", "incompleteTask");
      taskButton.classList.add("taskButton", "incompleteTask");
    }

    taskNButtonContainer.appendChild(taskTitle);
    taskNButtonContainer.appendChild(taskButton);
    taskNButtonContainer.appendChild(document.createElement("br"));

    const taskProgress = document.getElementById("taskProgress");
    taskProgress.appendChild(taskNButtonContainer);
  }

  function changeTaskStatus(taskId, status) {
    fetch("dashboard.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body:
        "task_id=" +
        encodeURIComponent(taskId) +
        "&status=" +
        encodeURIComponent(status) +
        "&action=update_status",
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Status update response:", data);

        if (data.success) {
          console.log("Task status updated successfully");
        } else {
          console.error("Failed to update task status:", data.error);
        }
      })
      .catch((error) => console.error("Error:", error));
  }

  document.addEventListener("click", function (e) {
    if (e.target.classList.contains("task")) {
      const taskContainer = e.target.closest(".taskNButton");

      const taskId = taskContainer.dataset.taskId;
      const taskName = taskContainer.dataset.taskName;
      const friendName = taskContainer.dataset.friendName;
      const dueDate = taskContainer.dataset.dueDate;
      const timeSpent = taskContainer.dataset.timeSpent;

      const editTaskFrame = document.getElementById("viewTaskFrame");
      editTaskFrame.classList.add("active");

      const editTaskId = document.getElementById("editTaskId");
      const editableActivity = document.getElementById("editableActivity");
      const editableFriend = document.getElementById("editableFriend");
      const editableDueDate = document.getElementById("editableDueDate");
      const timeSpentInput = document.getElementById("timeSpent");

      editTaskId.value = taskId;
      editableActivity.value = taskName;
      editableFriend.value = friendName;
      editableDueDate.value = dueDate;
      timeSpentInput.value = timeSpent;
    }
  });

  document
    .getElementById("closeButtonEditTask")
    .addEventListener("click", function () {
      document.getElementById("viewTaskFrame").classList.remove("active");
    });

  document
    .getElementById("editTaskForm")
    .addEventListener("submit", function (e) {
      e.preventDefault();

      const taskId = document.getElementById("editTaskId").value;
      const taskName = document.getElementById("editableActivity").value;
      const friendName = document.getElementById("editableFriend").value;
      const checkFriendName = friendName || "";
      const dueDate = document.getElementById("editableDueDate").value;

      editTaskData(taskId, taskName, checkFriendName, dueDate);
    });

  function editTaskData(taskId, taskName, friendName, dueDate) {
    const bodyData =
      "task_id=" +
      encodeURIComponent(taskId) +
      "&editActivityInput=" +
      encodeURIComponent(taskName) +
      "&editFriendInput=" +
      encodeURIComponent(friendName) +
      "&editDueDate=" +
      encodeURIComponent(dueDate) +
      "&action=edit_task";

    fetch("dashboard.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: bodyData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          alert("✅ Task updated successfully!");
          document.getElementById("viewTaskFrame").classList.remove("active");
          location.reload();
        } else {
          alert("Error: " + data.error);
        }
      });
  }

  const deleteTaskButton = document.getElementById("deleteTaskButton");
  deleteTaskButton.addEventListener("click", function () {
    const taskId = document.getElementById("editTaskId").value;
    deleteTask(taskId);
  });

  function deleteTask(taskId) {
    const bodyData =
      "task_id=" + encodeURIComponent(taskId) + "&action=delete_task";

    fetch("dashboard.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: bodyData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          alert("✅ Task deleted successfully!");
          document.getElementById("viewTaskFrame").classList.remove("active");
          location.reload();
        } else {
          alert("Error: " + data.error);
        }
      });
  }

  updateCalendar(month, year);
});
