<?php

$username = $_POST['username'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$password_comfirm = $_POST['password_comfirm'] ?? '';

if (strlen($password) < 8 || strlen($password) > 16) {
    echo '<script>alert("Password must be between 8 and 16 characters.")</script>';
    exit;
}

if (!preg_match('/[A-Z]/', $password)) {
    echo "<script>alert('Password must contains at least one uppercase letter')</script>";
    exit;
}

if (!preg_match('/[a-z]/', $password)) {
    echo "<script>alert('Password must contains at least one lowercase letter')</script>";
    exit;
}

if (!preg_match('/[0-9]/', $password)) {
    echo "<script>alert('Password must contains at least one number')</script>";
    exit;
}


include "tng_conn.php";

$check_sql_username = "SELECT * FROM User_Info WHERE Username = ?";
$stmt_username = $dbConn->prepare($check_sql_username);
$stmt_username->bind_param("s", $username);
$stmt_username->execute();
$result_username = $stmt_username->get_result();

$check_sql_email = "SELECT * FROM User_Info WHERE EmailAccount = ?";
$stmt_email = $dbConn->prepare($check_sql_email);
$stmt_email->bind_param("s", $email);
$stmt_email->execute();
$result_email = $stmt_email->get_result();

if ($result_username->num_rows > 0) {
    echo "<script>alert('Username already exists!'); window.history.back();</script>";
} elseif ($result_email->num_rows > 0) {
    echo "<script>alert('This email has been registered before!'); window.history.back();</script>";
} else {
    $sql = "INSERT INTO User_Info (Username, EmailAccount, UserPassword) VALUES ('$username','$email','$password');";
    mysqli_query($dbConn, $sql);

    if (mysqli_affected_rows($dbConn) <= 0) {
        die("<script>alert('Fail: unable to insert data!');window.history.go(-1);</script>");
    } else {
        $check_sql_email = "SELECT * FROM User_Info WHERE EmailAccount = ?";
        $stmt_email = $dbConn->prepare($check_sql_email);
        $stmt_email->bind_param("s", $email);
        $stmt_email->execute();
        $result_email = $stmt_email->get_result();
        if ($result_email->num_rows > 0) {
            $row = $result_email->fetch_assoc();
            $user_id = $row['UserID'];

            session_start();

            $_SESSION['user_email'] = $email;
            $_SESSION['username'] = $username;
            $_SESSION['userid'] = $user_id;
            setcookie('user_email', $email, 0, "/");
            setcookie('username', $username, 0, "/");
            setcookie('userid', $user_id, 0, "/");
            echo "<script>alert('Successfully Register!');</script>";
            header('Location: index.php');
            exit();
        }
    }
}


// if ($_SESSION['username'] && $_SESSION['email'] &&  $_SESSION['password']) {
//     echo "<script>
//         alert('Registration Successful!');
//         window.location.href='Register_Page_Html.html'; // 提交后返回注册页面
//         </script>";

// } else {
//     echo "<script>
//         alert('Please fill in the blank!');
//         window.location.href='Register_Page_Html.html'; // 提交后返回注册页面
//     </script>";
// }
