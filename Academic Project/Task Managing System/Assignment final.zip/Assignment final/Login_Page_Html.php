<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login_Page</title>
    <link rel="stylesheet" href="./Login_Page_Style.css">
    <script>
      function togglePassword() {
        const pwd = document.getElementById("password");
        const eye = document.getElementById("eye");

        if (pwd.type === "password") {
          pwd.type = "text";
          eye.src = "./image assets/hidden_eye.png"; // 显示密码时的图标
        } else {
          pwd.type = "password";
          eye.src = "./image assets/eye (1).png"; // 隐藏密码时的图标
        }
      }
    </script>
</head>
<body>
    <form class="Login_Page" action="Login_Page_PHP.php" method="POST">
        <h1>Welcome to TnG</h1>
        <input type="email" class="email" name="email" placeholder="Email"  value="<?php echo $_COOKIE['user_email'] ?? ''; ?>" required>
        <div class="pass">
        <input
          type="password"
          id="password"
          class="password"
          name="password"
          placeholder="Password"
          required
        />
        <span onclick="togglePassword()" >
                <img src="./image assets/eye (1).png" alt="" class="eye" id="eye">
            </span>
      </div>
        <button type="submit" class="login">Login</button>
        <a href="./Reset_Password_Html.html" class="f_password">Forgot Password?</a>
        <br>
        <br>
        <p class="sign_up">Haven't Sign Up Yet? <b><u><a href="./Register_Page_Html.html">Sign Up</a></u></b></p>      
    </form>
</body>
</html>