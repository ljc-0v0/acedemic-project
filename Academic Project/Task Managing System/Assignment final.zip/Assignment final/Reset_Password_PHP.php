<?php

    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $password_comfirm = $_POST['password_comfirm'] ?? '';

    include "tng_conn.php";

    $check_sql_email = "SELECT * FROM User_Info WHERE EmailAccount = ?";
    $stmt_email = $dbConn->prepare($check_sql_email);
    $stmt_email->bind_param("s", $email);
    $stmt_email->execute();
    $result_email = $stmt_email->get_result();

    if($result_email->num_rows > 0){
        if ($password !== $password_comfirm) {
            echo "<script>alert('Password does not match!'); window.history.back();</script>";
        } else {
            $sql = "UPDATE User_Info SET UserPassword = ? WHERE EmailAccount = ?";
            $stmt = $dbConn->prepare($sql);
            $stmt->bind_param("ss", $password, $email);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                echo "<script>alert('Password reset successfully!');window.location.href = 'Login_Page_Html.php';</script>";
            } else {
                echo "<script>alert('Failed to reset password!'); window.history.back();</script>";
            }
        }
    }else {
        echo "<script>alert('Email Incorrect!'); window.history.back();</script>";
    }
    
?>