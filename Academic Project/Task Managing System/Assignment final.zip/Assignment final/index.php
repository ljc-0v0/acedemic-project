<?php
session_start();
include('conn.php');

if (!isset($_SESSION['userid'])) {
  header('Location: Login_Page_Html.php');
  exit();
}

$user_id = $_SESSION['userid'];

$query = "SELECT * FROM user_info WHERE userid = ?";
$stmt = $dbConn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt->close();
$dbConn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Home Page</title>
  <link rel="stylesheet" href="calendar.css" />
  <script src="dashboardScript.js"></script>

  <style>
    nav.navbar {
      position: fixed;
      top: 0;
      left: 0;
      height: 100vh;
      width: 90px;
      background-color: white;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: start;
      padding-top: 20px;
      background: rgba(234, 243, 255, 0.5);
      backdrop-filter: blur(8px);
      z-index: 10;
    }

    nav.navbar a img {
      display: block;
      margin: 15px auto;
      width: 70px;
      height: 70px;
      object-fit: contain;
      transition: transform 0.2s;
    }

    nav.navbar a img:hover {
      transform: scale(1.1);
    }

    nav.navbar a img#navProfilePic {
      border-radius: 50%;
      object-fit: cover;
    }

    nav.navbar a.active img {
      transform: scale(1.12);
      filter: drop-shadow(0 0 4px rgba(0, 180, 255, 0.8)) drop-shadow(0 0 10px rgba(0, 180, 255, 0.8)) drop-shadow(0 0 20px rgba(0, 180, 255, 0.6));
      transition: transform 0.2s ease, filter 0.3s ease;
    }
  </style>
</head>

<body>
  <img id="bgImage"
    src="<?php echo !empty($user['BackgroundPicture']) ? htmlspecialchars($user['BackgroundPicture']) : 'default.jpg'; ?>"
    alt="BackgroundPicture"
    style="width:100%; height:100%; position:fixed; top:0; left:0; z-index:-1; object-fit:cover;">

  <nav class="navbar">
    <a href="Profile_Page.php" data-page="Profile_Page.php">
      <img id="navProfilePic"
        src="<?php echo !empty($user['ProfilePicture']) ? htmlspecialchars($user['ProfilePicture']) : 'image assets/Profile.png'; ?>"
        alt="Profile" width="70px" height="70px" style="object-fit: cover; border-radius: 50%;">
    </a>
    <a href="index.php" data-page="index.php"><img src="image assets/Home.png" alt="Home" width="42px" height="60px"></a>
  </nav>

  <form method="POST" action="dashboard.php" class="search-container">
    <input type="hidden" name="action" value="searchFriend">
    <input type="text" name="searchFriend" placeholder="Search User" class="search-input">
    <input type="submit" value="Search" name="submit" class="search-button">
  </form>

  <div class="dashBoard">

    <div class="taskProgress" id="taskProgress">
      <h1 id="selectedDate"></h1>
      <button id="addTaskButton" class="addTaskButton">+ New Task</button>
    </div>

    <div class="calendar">
      <div class="calendarHeader">
        <button class="navButton" id="prevMonth">&lt;</button>
        <h1 class="currentMonth" id="monthYear">month year</h1>
        <button class="navButton" id="nextMonth">&gt;</button>
      </div>
      <div class="weekdays">
        <div class="mon">Mon</div>
        <div class="tue">Tue</div>
        <div class="wed">Wed</div>
        <div class="thu">Thu</div>
        <div class="fri">Fri</div>
        <div class="sat">Sat</div>
        <div class="sun">Sun</div>
      </div>
      <div class="days" id="dayGrid"></div>
    </div>
  </div>

  <div id="frame" class="frame">
    <form action="dashboard.php" method="post" id="taskForm">
      <button class="closeButton" id="closeButton" type="button">X</button>
      <br />
      <table>
        <tr>
          <td><label for="activity" class="lbl_activity">Activity:</label></td>
          <td><input type="text" name="activity" class="activity" placeholder="Enter An Activity" required /></td>
        </tr>
        <tr>
          <td><label for="friend">Friend:</label></td>
          <td><input type="text" name="friend" class="friend" placeholder="Choose A Friend" /></td>
        </tr>
        <tr>
          <td><label for="dueDate">Date:</label></td>
          <td>
            <h1 id="selectedDateInForm"></h1>
            <input type="hidden" id="dueDateInput" name="dueDate" />
          </td>
        </tr>
        <tr>
          <td></td>
          <td>
            <input type="submit" value="Submit" name="submitForm" class="submit" />
            <input type="reset" value="Reset" class="reset" />
          </td>
        </tr>
      </table>
    </form>
  </div>

  <div id="viewTaskFrame" class="frame">
    <form action="dashboard.php" method="post" id="editTaskForm">
      <button class="closeButton" id="closeButtonEditTask" type="button">X</button>
      <input type="hidden" id="editTaskId" name="task_id">
      <br />
      <table>
        <tr>
          <td><label for="editActivityInput">Activity:</label></td>
          <td><input type="text" id="editableActivity" name="editActivityInput" class="editActivityInput"></td>
        </tr>
        <tr>
          <td><label for="editFriendInput">Friend:</label></td>
          <td><input type="text" id="editableFriend" name="editFriendInput" class="editFriendInput" /></td>
        </tr>
        <tr>
          <td><label for="editDueDate">Date:</label></td>
          <td><input type="date" id="editableDueDate" name="editDueDate" class="editDueDate" /></td>
        </tr>
        <tr>
          <td><label for="timeSpent">Time Spent:</label></td>
          <td><input type="text" id="timeSpent" name="timeSpent" class="editDueDate" readonly /></td>
        </tr>
        <tr>
          <td></td>
          <td>
            <input type="submit" value="Update" name="updateForm" class="update" />
            <button type="button" id='deleteTaskButton' class="deleteButton">Delete</button>
          </td>
        </tr>
      </table>
    </form>
  </div>

  <script>
    const currentPage = window.location.pathname.split("/").pop();
    document.querySelectorAll("nav.navbar a").forEach(link => {
      const page = link.getAttribute("data-page");
      if (page === currentPage) {
        link.classList.add("active");
      }
    });

    const navProfilePic = document.getElementById("navProfilePic");
    window.addEventListener("load", () => {
      const savedProfile = localStorage.getItem("profilePic");
      if (savedProfile) {
        navProfilePic.src = savedProfile;
      }
    });

    const bgImage = document.getElementById("bgImage");
    window.addEventListener("load", () => {
      const savedBg = localStorage.getItem("backgroundImage");
      if (savedBg) {
        bgImage.src = savedBg;
      }
    });
  </script>

</body>

</html>