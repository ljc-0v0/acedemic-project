<?php
session_start();
include('conn.php');

if (!isset($_SESSION['userid'])) {
    header("Location: Login_Page_Html.php");
    exit();
}

$friendUserID = $_GET['friendID'];

$query = "SELECT * FROM user_info WHERE userid = ?";
$stmt = $dbConn->prepare($query);
$stmt->bind_param("i", $friendUserID);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt->close();
$dbConn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Profile Page</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f1f5fb;
            background-size: cover;
            background-position: center;
            transition: background-image 0.4s ease;
        }

        .main-content {
            margin-left: 0px;
            padding: 20px;
        }

        .profile-card {
            display: flex;
            align-items: center;
            background: rgba(234, 243, 255, 0.5);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .profile-photo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin-right: 20px;
            transition: transform 0.2s;
        }

        .profile-photo:hover {
            transform: scale(1.05);
        }

        .profile-info h2 {
            margin: 0;
            font-size: 24px;
        }

        .profile-info p {
            margin: 5px 0;
            color: #333;
        }

        .info-section {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            background: rgba(234, 243, 255, 0.45);
            border-radius: 10px;
            padding: 20px;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }


        .info-fields {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .info-fields label {
            font-weight: bold;
        }

        .info-fields input {
            padding: 6px;
            border-radius: 6px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            width: 250px;
            background-color: rgba(255, 255, 255, 0.6);
        }

        .chart-section {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .sort-box {
            margin-bottom: 25px;
        }

        .backButton {
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            color: #ffffff;
            border: none;
            padding: 2px 8px;
            border-radius: 15px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s ease-in-out;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.15);
        }

        .backButton:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.25);
            filter: brightness(1.1);
        }

        .backButton:active {
            transform: scale(0.97);
        }
    </style>
</head>

<body>
    <div class="main-content">
        <form action="dashboard.php" method="post">
            <input type="hidden" name="action" value="backButton">
            <input type="submit" value="Back" class='backButton'>
        </form>
        <div class="profile-card">
            <img class="profile-photo" id="profilePic"
                src="<?php echo !empty($user['ProfilePicture']) ? htmlspecialchars($user['ProfilePicture']) : 'image assets/Profile.png'; ?>"
                alt="Profile Picture">
            <input type="file" id="profileUploader" accept="image/*" style="display:none;">
            <div class="profile-info">
                <h2><?php echo htmlspecialchars($user['Username']); ?></h2>
                <p><?php echo htmlspecialchars($user['EmailAccount']); ?></p>
            </div>
        </div>

        <div class="info-section">
            <div class="info-fields">

                <div>
                    <label>DOB:</label>
                    <input type="date" id="dob" value="<?php echo $user['DateofBirth']; ?>" readonly>
                </div>

                <div>
                    <label>Phone.no:</label>
                    <input type="text" value="<?php echo $user['PhoneNumber']; ?>" readonly>
                </div>

                <div>
                    <label>Facebook:</label>
                    <input type="text" value="<?php echo $user['FacebookAccount']; ?>" readonly>
                </div>

                <div>
                    <label>Instagram:</label>
                    <input type="text" value="<?php echo $user['InstagramAccount']; ?>" readonly>
                </div>
            </div>

            <div class="chart-section">
                <div class="sort-box">
                    <label>Sort by:</label>
                    <select id="periodSelect">
                        <option value="month">Month</option>
                        <option value="week">Week</option>
                        <option value="year">Year</option>
                    </select>
                </div>
                <canvas id="Status" width="250" height="250"></canvas>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        window.addEventListener("load", () => {
            const savedProfile = localStorage.getItem("profilePic");
            const savedBg = localStorage.getItem("backgroundImage");

            if (savedProfile) {
                profilePic.src = savedProfile;
                navProfilePic.src = savedProfile;
            }
            if (savedBg) {
                document.body.style.backgroundImage = `url('${savedBg}')`;
            }

            document.querySelectorAll(".info-fields input").forEach(input => {
                const key = input.previousElementSibling.textContent.trim();
                const savedValue = localStorage.getItem(key);
                if (savedValue) {
                    input.value = savedValue;
                }
            });
        });

        document.addEventListener("DOMContentLoaded", () => {
            fetch("Load_Chart.php")
                .then(res => res.json())
                .then(data => {
                    if (!data.success) return console.error("Failed to load chart:", data.message);

                    const completed = data.data.completed || 0;
                    const incomplete = data.data.incomplete || 0;

                    const ctx = document.getElementById("Status").getContext("2d");
                    let chart;

                    function loadChart(period = "month") {
                        fetch(`Load_Chart.php?period=${period}`)
                            .then(res => res.json())
                            .then(data => {
                                if (!data.success) return console.error("Failed to load chart:", data.message);

                                let totalCompleted = 0;
                                let totalIncomplete = 0;
                                for (const key in data.data) {
                                    totalCompleted += data.data[key].completed || 0;
                                    totalIncomplete += data.data[key].incomplete || 0;
                                }

                                if (chart) chart.destroy();

                                chart = new Chart(ctx, {
                                    type: "doughnut",
                                    data: {
                                        labels: ["Completed", "Incomplete"],
                                        datasets: [{
                                            data: [totalCompleted, totalIncomplete],
                                            backgroundColor: ["#34d399", "#f87171"],
                                            borderColor: ["#ffffff"],
                                            borderWidth: 2
                                        }]
                                    },
                                    options: {
                                        responsive: true,
                                        plugins: {
                                            legend: {
                                                position: "bottom"
                                            },
                                            title: {
                                                display: true,
                                                text: "Task Completion Status (" + period.charAt(0).toUpperCase() + period.slice(1) + ")"
                                            }
                                        },
                                        cutout: "60%"
                                    }
                                });
                            })
                            .catch(err => console.error("Error fetching chart data:", err));
                    }

                    loadChart();

                    document.getElementById("periodSelect").addEventListener("change", (e) => {
                        loadChart(e.target.value);
                    });
                });
        });
    </script>

</html>