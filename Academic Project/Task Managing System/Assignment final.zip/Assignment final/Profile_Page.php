<?php
session_start();
include('tng_conn.php');

if (!isset($_SESSION['userid'])) {
  header("Location: Login_Page_Html.php");
  exit();
}

$user_id = $_SESSION['userid'];

$query = "SELECT * FROM user_info WHERE userid = ?";
$stmt = $dbConn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt->close();
$dbConn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Profile Page</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f1f5fb;
      background-size: cover;
      background-position: center;
      transition: background-image 0.4s ease;
    }

    .main-content {
      margin-left: 100px;
      padding: 20px;
    }

    .profile-card {
      display: flex;
      align-items: center;
      background: rgba(234, 243, 255, 0.5);
      border-radius: 10px;
      padding: 15px 20px;
      margin-bottom: 20px;
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .profile-photo {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      margin-right: 20px;
      cursor: pointer;
      transition: transform 0.2s;
    }

    .profile-photo:hover {
      transform: scale(1.05);
    }

    .profile-info h2 {
      margin: 0;
      font-size: 24px;
    }

    .profile-info p {
      margin: 5px 0;
      color: #333;
    }

    .edit img {
      width: 18px;
      height: 18px;
      cursor: pointer;
      vertical-align: middle;
    }

    .info-section {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      background: rgba(234, 243, 255, 0.45);
      border-radius: 10px;
      padding: 20px;
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }


    .info-fields {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    .info-fields label {
      font-weight: bold;
    }

    .info-fields input {
      padding: 6px;
      border-radius: 6px;
      border: 1px solid rgba(255, 255, 255, 0.3);
      width: 250px;
      background-color: rgba(255, 255, 255, 0.6);
    }


    .chart-section {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .sort-box {
      margin-bottom: 25px;
    }

    .change-bg,
    .logout-btn {
      margin-top: 20px;
      padding: 8px 16px;
      border: 1px solid #ccc;
      border-radius: 6px;
      background-color: white;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      justify-content: center;
    }

    .change-bg img {
      width: 20px;
      height: 20px;
    }

    .logout-btn {
      background-color: red;
      color: white;
      font-weight: bold;
      width: 100%;
      max-width: 150px;
      border: none;
    }

    .logout-btn:hover {
      background-color: cyan;
      color: black;
    }

    nav.navbar {
      position: fixed;
      top: 0;
      left: 0;
      height: 100vh;
      width: 90px;
      background-color: white;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: start;
      padding-top: 20px;
      background: rgba(234, 243, 255, 0.5);
      backdrop-filter: blur(8px);
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    nav.navbar a img {
      display: block;
      margin: 15px auto;
      transition: transform 0.2s;
      border-radius: 0%;
    }

    nav.navbar a img:hover {
      transform: scale(1.1);
    }

    nav.navbar a.active img {
      transform: scale(1.12);
      filter: drop-shadow(0 0 4px rgba(0, 180, 255, 0.8)) drop-shadow(0 0 10px rgba(0, 180, 255, 0.8)) drop-shadow(0 0 20px rgba(0, 180, 255, 0.6));
      transition: transform 0.2s ease, filter 0.3s ease;
    }

    nav.navbar a:hover {
      background-color: #f0f9ff;
      border-radius: 10px;
    }

    nav.navbar a img#navProfilePic {
      border-radius: 50%;
      width: 70px;
      height: 70px;
      object-fit: cover;
      transition: transform 0.2s, box-shadow 0.2s;
    }
  </style>
</head>

<body>

  <img id="bgImage"
    src="<?php echo !empty($user['BackgroundPicture']) ? htmlspecialchars($user['BackgroundPicture']) : 'default.jpg'; ?>"
    style="width:100%; height:100%; position:fixed; top:0; left:0; z-index:-1; object-fit:cover;">


  <nav class="navbar">
    <a href="Profile_Page.php" data-page="Profile_Page.php">
      <img id="navProfilePic"
        src="<?php echo !empty($user['ProfilePicture']) ? htmlspecialchars($user['ProfilePicture']) : 'image assets/Profile.png'; ?>"
        alt="Profile" width="70px" height="70px" style="object-fit: cover; border-radius: 50%;">
    </a>
    <a href="index.php" data-page="index.php"><img src="image assets/Home.png" alt="Home" width="42px" height="60px"></a>

  </nav>

  <div class="main-content">
    <div class="profile-card">
      <img class="profile-photo" id="profilePic"
        src="<?php echo !empty($user['ProfilePicture']) ? htmlspecialchars($user['ProfilePicture']) : 'image assets/Profile.png'; ?>"
        alt="Profile Picture">
      <input type="file" id="profileUploader" accept="image/*" style="display:none;">
      <div class="profile-info">
        <h2><?php echo htmlspecialchars($user['Username']); ?></h2>
        <p><?php echo htmlspecialchars($user['EmailAccount']); ?></p>
      </div>
    </div>

    <div class="info-section">
      <div class="info-fields">

        <div>
          <label>DOB:</label>
          <input type="date" id="dob" value="<?php echo $user['DateofBirth']; ?>" readonly>
          <span class="edit"><img src="image assets/edit.png" alt="Edit"></span>
        </div>

        <div>
          <label>Phone.no:</label>
          <input type="text" value="<?php echo $user['PhoneNumber']; ?>" readonly>
          <span class="edit"><img src="image assets/edit.png" alt="Edit"></span>
        </div>

        <div>
          <label>Facebook:</label>
          <input type="text" value="<?php echo $user['FacebookAccount']; ?>" readonly>
          <span class="edit"><img src="image assets/edit.png" alt="Edit"></span>
        </div>

        <div>
          <label>Instagram:</label>
          <input type="text" value="<?php echo $user['InstagramAccount']; ?>" readonly>
          <span class="edit"><img src="image assets/edit.png" alt="Edit"></span>
        </div>

        <button class="change-bg"><img src="image assets/edit.png" alt="Change">Change Background</button>
        <input type="file" id="bgUploader" accept="image/*" style="display:none;">
        <button class="logout-btn" id="logoutBtn">Logout</button>
      </div>

      <div class="chart-section">
        <div class="sort-box">
          <label>Sort by:</label>
          <select id="periodSelect">
            <option value="week">Week</option>
            <option value="month">Month</option>
            <option value="year">Year</option>
          </select>
        </div>
        <canvas id="Status" width="250" height="250"></canvas>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    const profilePic = document.getElementById("profilePic");
    const navProfilePic = document.getElementById("navProfilePic");
    const profileUploader = document.getElementById("profileUploader");

    profilePic.addEventListener("click", () => profileUploader.click());
    profileUploader.addEventListener("change", event => {
      const file = event.target.files[0];
      if (file) {
        const formData = new FormData();
        formData.append("field", "ProfilePicture");
        formData.append("file", file);

        fetch("update_profile.php", {
            method: "POST",
            body: formData
          })
          .then(res => res.json())
          .then(data => {
            if (data.success) {
              profilePic.src = data.path;
              navProfilePic.src = data.path;
              alert("Profile picture updated successfully!");
            } else {
              alert("Upload failed: " + data.message);
            }
          })
          .catch(err => {
            console.error("Upload error:", err);
            alert("Upload failed, please try again.");
          });
      }
    });

    const bgUploader = document.getElementById("bgUploader");
    const changeBgBtn = document.querySelector(".change-bg");
    const bgImage = document.getElementById("bgImage");

    changeBgBtn.addEventListener("click", () => bgUploader.click());
    bgUploader.addEventListener("change", event => {
      const file = event.target.files[0];
      if (file) {
        const formData = new FormData();
        formData.append("field", "BackgroundPicture");
        formData.append("file", file);

        fetch("update_profile.php", {
            method: "POST",
            body: formData
          })
          .then(res => res.json())
          .then(data => {
            if (data.success) {
              bgImage.src = data.path;
              localStorage.setItem("backgroundImage", data.path);
              alert("Background updated successfully!");
            } else {
              alert("Upload failed: " + data.message);
            }
          })
          .catch(err => {
            console.error("Upload error:", err);
            alert("Upload failed, please try again.");
          });
      }
    });

    window.addEventListener("load", () => {
      const savedProfile = localStorage.getItem("profilePic");
      const savedBg = localStorage.getItem("backgroundImage");

      if (savedProfile) {
        profilePic.src = savedProfile;
        navProfilePic.src = savedProfile;
      }
      if (savedBg) {
        bgImage.src = savedBg;
      }

      document.querySelectorAll(".info-fields input").forEach(input => {
        const key = input.previousElementSibling.textContent.trim();
        const savedValue = localStorage.getItem(key);
        if (savedValue) {
          input.value = savedValue;
        }
      });
    });

    document.querySelectorAll(".edit img").forEach(icon => {
      icon.addEventListener("click", () => {
        const input = icon.closest("div").querySelector("input");


        if (input.hasAttribute("readonly")) {
          input.removeAttribute("readonly");
          input.style.border = "1px solid #00aaff";
          input.style.backgroundColor = "#fff";
          input.focus();
        } else {
          input.setAttribute("readonly", true);
          input.style.border = "1px solid #ccc";
          input.style.backgroundColor = "rgba(255,255,255,0.6)";

          const fieldLabel = input.previousElementSibling.textContent.trim();
          const fieldValue = input.value;

          fetch('update_profile.php', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                field: fieldLabel,
                value: fieldValue
              })
            })
            .then(res => res.json())
            .then(data => {
              if (data.success) {
                alert(`${fieldLabel} updated successfully!`);
              } else {
                alert(`Update failed: ${data.message}`);
              }
            })
            .catch(err => {
              console.error("Update error:", err);
              alert("System error, please try again later.");
            });
        }
      });
    });


    document.getElementById("logoutBtn").addEventListener("click", () => {
      const confirmLogout = confirm("Are you sure you want to logout?");
      if (confirmLogout) {
        document.cookie.split(";").forEach(cookie => {
          const eqPos = cookie.indexOf("=");
          const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
          document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/";
        });

        localStorage.clear();

        fetch("Logout.php", {
            method: "POST"
          })
          .then(() => {
            window.location.href = "Login_Page_Html.php";
          })
          .catch(() => {
            window.location.href = "Login_Page_Html.php";
          });
      }
    });

    document.addEventListener("DOMContentLoaded", () => {
      const ctx = document.getElementById("Status").getContext("2d");
      let chart = null;

      function getCurrentPeriod(periodType) {
        const now = new Date();
        const year = now.getFullYear();

        if (periodType === "year") {
          return `${year}`;
        }

        if (periodType === "month") {
          const month = String(now.getMonth() + 1).padStart(2, "0");
          return `${year}-${month}`;
        }

        if (periodType === "week") {
          const firstJan = new Date(now.getFullYear(), 0, 1);
          const days = Math.floor((now - firstJan) / (24 * 60 * 60 * 1000));
          const week = Math.ceil((days + firstJan.getDay() + 1) / 7);
          return `${year}-W${String(week).padStart(2, "0")}`;
        }

        return `${year}-${String(now.getMonth() + 1).padStart(2, "0")}`;
      }

      function loadChart(period = "week") {
        fetch(`Load_Chart.php?period=${period}`)
          .then(res => res.json())
          .then(data => {
            if (!data.success) {
              console.error("Failed to load chart:", data.message);
              return;
            }

            const labels = Object.keys(data.data);
            if (labels.length === 0) {
              console.warn("No data available");
              return;
            }

            const currentPeriod = getCurrentPeriod(period);
            const periodData = data.data[currentPeriod] || {
              completed: 0,
              incomplete: 0
            };

            if (chart) chart.destroy();

            chart = new Chart(ctx, {
              type: "doughnut",
              data: {
                labels: ["Completed", "Incomplete"],
                datasets: [{
                  data: [periodData.completed, periodData.incomplete],
                  backgroundColor: ["#34d399", "#f87171"],
                  borderColor: ["#ffffff"],
                  borderWidth: 2
                }]
              },
              options: {
                responsive: true,
                plugins: {
                  legend: {
                    position: "bottom"
                  },
                  title: {
                    display: true,
                    text: `Task Completion (${period.toUpperCase()})`
                  }
                },
                cutout: "60%"
              }
            });
          })
          .catch(err => console.error("Error fetching chart data:", err));
      }

      document.getElementById("periodSelect").value = "week";
      loadChart("week");

      document.getElementById("periodSelect").addEventListener("change", (e) => {
        loadChart(e.target.value);
      });
    });


    const currentPage = window.location.pathname.split("/").pop();
    document.querySelectorAll("nav.navbar a").forEach(link => {
      const page = link.getAttribute("data-page");
      if (page === currentPage) {
        link.classList.add("active");
      }
    });
  </script>

</html>